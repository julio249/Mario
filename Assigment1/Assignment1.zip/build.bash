#!/bin/bash
set -u -e
javac Assignment1.java
java Assignment1